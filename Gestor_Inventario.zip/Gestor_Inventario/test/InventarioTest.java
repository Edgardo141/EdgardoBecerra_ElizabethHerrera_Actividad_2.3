import org.junit.Test; // Cambia la anotación Test
import static org.junit.Assert.*; // Cambia la importación de Assertions


public class InventarioTest {

    // Prueba que verifica si agregar stock funciona correctamente
    @Test
    public void testAgregarStock() {
        Producto p = new Producto("Teclado", 7); 
        p.agregarStock(5);                       
        assertEquals(12, p.getStock());
    }

    // Prueba que verifica si restar stock válido funciona correctamente
    @Test
    public void testRestarStock() {
        Producto p = new Producto("Mouse", 10);
        boolean resultado = p.restarStock(3);
        assertTrue(resultado);
        assertEquals(7, p.getStock());
    }

    // Prueba que verifica que no se puede restar más stock del disponible
    @Test 
    public void testRestarStockNegativo() {
        Producto p = new Producto("Monitor", 10);
        boolean resultado = p.restarStock(11);
        assertFalse(resultado);
        assertEquals(10, p.getStock());
    }
}