import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InventarioTest {

    @Test
    public void testAgregarStock() {
        Producto p = new Producto("Teclado", 7); 
        p.agregarStock(5);                       
        assertEquals(12, p.getStock());
    }

    @Test
    public void testRestarStock() {
        Producto p = new Producto("Mouse", 10);
        boolean resultado = p.restarStock(3);
        assertTrue(resultado);
        assertEquals(7, p.getStock());
    }

    @Test
    public void testRestarStockNegativo() {
        Producto p = new Producto("Monitor", 10);
        boolean resultado = p.restarStock(11);
        assertFalse(resultado);
        assertEquals(10, p.getStock());
    }
}
