import java.util.ArrayList;

// Clase que representa el inventario de productos
public class Inventario {

    // Lista dinámica que almacena todos los productos registrados
    private ArrayList<Producto> productos;

    // Constructor: inicializa la lista vacía al crear el inventario
    public Inventario() {
        productos = new ArrayList<>();
    }

    // Método para agregar un nuevo producto al inventario
    // Recibe el nombre del producto y su stock inicial
    public void agregarProducto(String nombre, int stockInicial) {
        productos.add(new Producto(nombre, stockInicial));
    }

    // Devuelve la lista completa de productos registrados
    public ArrayList<Producto> listarProductos() {
        return productos;
    }

    // Busca un producto por su nombre (sin importar mayúsculas/minúsculas)
    // Retorna el objeto Producto si lo encuentra, o null si no existe
    public Producto buscarProducto(String nombre) {
        for (Producto p : productos) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                return p;
            }
        }
        return null;
    }

    // Muestra en consola todos los productos del inventario
    public void reporteInventarioTotal() {
        System.out.println("📦 Inventario Total:");
        for (Producto p : productos) {
            System.out.println(p); 
        }
    }

    // Muestra los productos cuyo stock es menor o igual al umbral crítico
    public void reporteStockCritico(int umbral) {
        System.out.println("⚠️ Stock Crítico (menor o igual a " + umbral + "):");
        for (Producto p : productos) {
            if (p.getStock() <= umbral) {
                System.out.println(p);
            }
        }
    }
}
