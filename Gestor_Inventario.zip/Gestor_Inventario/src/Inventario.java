import java.util.ArrayList;

public class Inventario {
    private ArrayList<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(String nombre, int stockInicial) {
        productos.add(new Producto(nombre, stockInicial));
    }

    public ArrayList<Producto> listarProductos() {
        return productos;
    }

    public Producto buscarProducto(String nombre) {
        for (Producto p : productos) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                return p;
            }
        }
        return null;
    }

    public void reporteInventarioTotal() {
        System.out.println("📦 Inventario Total:");
        for (Producto p : productos) {
            System.out.println(p);
        }
    }

    public void reporteStockCritico(int umbral) {
        System.out.println("⚠️ Stock Crítico (menor o igual a " + umbral + "):");
        for (Producto p : productos) {
            if (p.getStock() <= umbral) {
                System.out.println(p);
            }
        }
    }
}