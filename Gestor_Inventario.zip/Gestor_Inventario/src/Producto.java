public class Producto {
    private String nombre;
    private int stock;

    public Producto(String nombre, int stockInicial) {
        this.nombre = nombre;
        this.stock = stockInicial;
    }

    public String getNombre() {
        return nombre;
    }

    public int getStock() {
        return stock;
    }


    // Método para agregar unidades al stock
    // Solo se permite si la cantidad es positiva
    public void agregarStock(int cantidad) {
        if (cantidad > 0) {
            stock += cantidad;
        }
    }

    // Método para restar unidades del stock
    // Solo se permite si la cantidad es positiva y no excede el stock actual
    // Retorna true si la operación fue exitosa, false si no se pudo realizar
    public boolean restarStock(int cantidad) {
        if (cantidad > 0 && cantidad <= stock) {
            stock -= cantidad;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return nombre + " - Stock: " + stock;
    }
}