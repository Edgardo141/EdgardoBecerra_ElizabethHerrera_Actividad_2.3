import java.util.Scanner;

// Clase principal que ejecuta el gestor de inventario desde consola
public class Main {
    public static void main(String[] args) {
        // Se crea una instancia del inventario y del scanner para leer entradas del usuario
        Inventario inventario = new Inventario();
        Scanner scanner = new Scanner(System.in);
        boolean activo = true; // Variable que controla el ciclo del menú

        // Bucle principal: se repite mientras 'activo' sea true
        while (activo) {
            // Menú de opciones para el usuario
            System.out.println("\n--- Gestor de Inventario ---");
            System.out.println("1. Crear producto");
            System.out.println("2. Listar productos");
            System.out.println("3. Agregar stock");
            System.out.println("4. Restar stock");
            System.out.println("5. Reporte inventario total");
            System.out.println("6. Reporte stock crítico");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            // Lectura de la opción seleccionada
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpia el buffer para evitar errores con nextLine()

            // Evaluación de la opción seleccionada mediante switch
            switch (opcion) {
                case 1: // Crear producto
                    System.out.print("Nombre del producto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Stock inicial: ");
                    int stock = scanner.nextInt();
                    inventario.agregarProducto(nombre, stock);
                    break;

                case 2: // Listar productos
                    for (Producto p : inventario.listarProductos()) {
                        System.out.println(p); // Muestra cada producto usando toString()
                    }
                    break;

                case 3: // Agregar stock a un producto existente
                    System.out.print("Producto: ");
                    nombre = scanner.nextLine();
                    Producto p1 = inventario.buscarProducto(nombre);
                    if (p1 != null) {
                        System.out.print("Cantidad a agregar: ");
                        int cantidad = scanner.nextInt();
                        p1.agregarStock(cantidad);
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;

                case 4: // Restar stock a un producto existente
                    System.out.print("Producto: ");
                    nombre = scanner.nextLine();
                    Producto p2 = inventario.buscarProducto(nombre);
                    if (p2 != null) {
                        System.out.print("Cantidad a restar: ");
                        int cantidad = scanner.nextInt();
                        if (!p2.restarStock(cantidad)) {
                            System.out.println("❌ No se puede restar esa cantidad.");
                        }
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;

                case 5: // Mostrar reporte completo del inventario
                    inventario.reporteInventarioTotal();
                    break;

                case 6: // Mostrar productos con stock crítico
                    System.out.print("Umbral crítico: ");
                    int umbral = scanner.nextInt();
                    inventario.reporteStockCritico(umbral);
                    break;

                case 0: // Salir del programa
                    activo = false;
                    break;

                default: // Opción inválida
                    System.out.println("Opción inválida.");
            }
        }

        // Cierre del scanner al finalizar el programa
        scanner.close();
    }
}
